<?php

/**
 * Created by PhpStorm.
 * User: liulipeng
 * Date: 16/3/9
 * Time: 下午12:14
 */
return [
    'This username has already been taken' => '这个用户名已经被使用了。',
    'This email address has already been taken' => '这个电子邮件地址已经被使用了。',
];