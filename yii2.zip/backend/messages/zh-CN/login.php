<?php
/**
 * Created by PhpStorm.
 * User: liulipeng
 * Date: 16/3/4
 * Time: 下午12:24
 */


return [
    'username or password error' => '用户名或密码错误',
    'rememberMe' => '记住我',
    'logout' => '退出',
];