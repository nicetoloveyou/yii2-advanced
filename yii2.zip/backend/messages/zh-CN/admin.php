<?php
/**
 * Created by PhpStorm.
 * User: liulipeng
 * Date: 16/3/4
 * Time: 下午12:46
 */


return [
    'adminSystem' => '后台管理系统',
    'dashboard' => '管理首页',
];