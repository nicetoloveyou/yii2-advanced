<?php
/**
 * Created by PhpStorm.
 * User: liulipeng
 * Date: 16/3/4
 * Time: 下午12:11
 */
return [
    'login' => '登录',
    'username' => '用户名',
    'email' => '邮箱',
    'verifyCode' => '验证码',
    'password' => '密码',
];